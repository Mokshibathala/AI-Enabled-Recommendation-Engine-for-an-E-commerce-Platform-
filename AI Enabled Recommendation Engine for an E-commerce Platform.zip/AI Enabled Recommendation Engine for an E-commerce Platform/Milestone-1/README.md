# Milestone 1: Data Preparation

## Project
AI Enabled Recommendation Engine for an E-commerce Platform 

---

## Objective
The objective of this milestone is to prepare clean and structured datasets required for developing an AI-based recommendation engine.

---

## Tasks Performed

### 1. Data Collection
Three datasets were prepared:
- User data
- Product data
- User–product interaction data

All datasets were stored in CSV format.

---

### 2. Data Cleaning and Preprocessing
- Removed data inconsistencies and formatting issues
- Handled missing values in user and product data
- Standardized column names and data formats

---

### 3. User–Item Interaction Matrix
A user–item interaction matrix was created where:
- Rows represent users
- Columns represent products
- Cell values represent interaction strength (ratings)

This matrix is used as the core input for recommendation algorithms.

---

## Output Files


---

## Evaluation Criteria Status

- Clean and structured datasets ready for training ✔  
- User–item interaction matrix created successfully ✔  

---

## Milestone Status

**Milestone 1 completed successfully.**
