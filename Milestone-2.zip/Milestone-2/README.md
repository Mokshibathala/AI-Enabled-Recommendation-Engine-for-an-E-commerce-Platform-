# Milestone 2: Model Building

## Project
AI Enabled Recommendation Engine for an E-commerce Platform 

---

## Objective
The objective of this milestone is to develop and train the core recommendation model using the prepared user–item interaction data.

---

## Model Selection
An **Item-Based Collaborative Filtering** approach was selected for the recommendation system.  
This method recommends products based on similarity between items derived from user interaction patterns.

---

## Algorithm Used
- Collaborative Filtering (Item-Based)
- Similarity Metric: **Cosine Similarity**

---

## Model Training
- The user–item interaction matrix created in Milestone 1 was used as input.
- An item–item similarity matrix was generated using cosine similarity.
- This similarity matrix represents the trained recommendation model.

---

## Recommendation Process
- Given a product ID, the model identifies similar products based on similarity scores.
- Top-N most similar products are returned as recommendations.

---

## Evaluation
- Recommendations were successfully generated for sample products.
- Similarity scores range between 0 and 1.
- The model produces meaningful and consistent recommendations based on user interaction data.

---

## Output Files
- `model_building.ipynb`
- `item_similarity_matrix.csv`

---

## Status
Milestone 2 completed successfully.
