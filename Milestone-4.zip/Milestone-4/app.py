from flask import Flask, request
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# -----------------------------
# LOAD USER–ITEM MATRIX
# -----------------------------
# Using a simple example matrix (replace with your saved matrix if needed)

data = {
    "101": [5, 0, 3, 0],
    "102": [4, 0, 0, 2],
    "103": [0, 3, 4, 0],
    "104": [0, 4, 5, 3],
    "105": [2, 0, 0, 4]
}

user_item_matrix = pd.DataFrame(data)

# Calculate item similarity
item_similarity = cosine_similarity(user_item_matrix.T)
item_similarity_df = pd.DataFrame(
    item_similarity,
    index=user_item_matrix.columns,
    columns=user_item_matrix.columns
)

# -----------------------------
# RECOMMENDATION FUNCTION
# -----------------------------
def recommend_products(product_id, top_n=3):
    if product_id not in item_similarity_df.columns:
        return []

    scores = item_similarity_df[product_id].sort_values(ascending=False)
    return list(scores.index[1:top_n+1])

# -----------------------------
# ROUTES
# -----------------------------
@app.route("/")
def home():
    return "Recommendation System is Running Successfully!"

@app.route("/recommend")
def recommend():
    product_id = request.args.get("product_id")

    if not product_id:
        return "Please provide a product_id"

    recommendations = recommend_products(product_id)
    return {
        "input_product": product_id,
        "recommended_products": recommendations
    }

# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)
