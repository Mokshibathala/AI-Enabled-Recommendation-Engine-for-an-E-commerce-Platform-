# Milestone 3: Evaluation and Refinement

## Project
AI Enabled Recommendation Engine for an E-commerce Platform – Group 2

---

## Objective
The objective of this milestone is to evaluate the performance of the recommendation model developed in Milestone 2 and refine the model to improve recommendation accuracy.

---

## Tasks Performed

### 1. Model Evaluation
The recommendation model was evaluated using standard evaluation metrics:
- Precision
- Recall
- F1-score

These metrics were calculated by comparing the model’s recommended products with the actual user–product interaction data.

---

### 2. Performance Analysis
The evaluation results showed low metric values due to the limited size of the dataset and sparse user interactions. Such results are expected in early-stage recommendation systems trained on small datasets.

---

### 3. Model Refinement
To refine the model and test different recommendation scenarios:
- The number of recommendations was varied (Top-3, Top-5, Top-10)
- Evaluation metrics were recalculated for each scenario

This demonstrates parameter tuning and refinement of the recommendation process.

---

## Results
- Precision, Recall, and F1-score were successfully calculated
- Different recommendation scenarios were tested
- Model performance limitations were identified

---

## Conclusion
Milestone 3 successfully validates the recommendation model using evaluation metrics and demonstrates refinement through parameter tuning. The results highlight the importance of larger datasets for improving recommendation accuracy.

---

## Files Included
- evaluation_and_refinement.ipynb
- Evaluation metrics calculation
- Model refinement experiments

---

Milestone 3 completed successfully.
